//diferentes preguntas con sus respectivas opciones y respuesta
const preguntas = [
    {
        titulo: "PREGUNTA 1",
        pregunta: "¿Cuál de estos huesos no se encuentra en el pie?",
        opciones: ["A. Astrágalo", "B. Calcáneo", "C. Semilunar", "D. Cuboides"],
        respuesta: 2,
    },
    {
        titulo: "PREGUNTA 2",
        pregunta: "¿Qué acción realizan los músculos isquiotibiales?",
        opciones: ["A. Flexión de cadera", "B. Flexión de rodilla y extensión de cadera", "C. Extensión de rodilla y flexión de cadera", "D. Extensión de cadera"],
        respuesta: 1,
    },
    {
        titulo: "PREGUNTA 3",
        pregunta: "¿Cuántos musculos tenemos en el antebrazo?",
        opciones: ["A. 10", "B. 20", "C. 16", "D. 5"],
        respuesta: 1,

    },
    {
        titulo: "PREGUNTA 4",
        pregunta: "¿Cuál es el hueso más largo del cuerpo humano?",
        opciones: ["A. Humero", "B. Tibia", "C. Fémur", "D. Radio"],
        respuesta: 2,

    },
    {
        titulo: "PREGUNTA 5",
        pregunta: "¿Qué huesos forman la articulación que realiza el movimiento de pronación y supinación?",
        opciones: ["A. Cúbito y humero", "B. Tibia y peroné", "C. Radio y Cúbito", "D. Húmero y radio"],
        respuesta: 2,

    },
    {
        titulo: "PREGUNTA 6",
        pregunta: "¿Qué músculos realizan la eversión?",
        opciones: ["A. Peroneos", "B. Isquiotibiales", "C. Cuádriceps", "D. Tibiales"],
        respuesta: 0,
    },

    {
        titulo: "PREGUNTA 7",
        pregunta: "¿Qué hueso no forma parte de la mano?",
        opciones: ["A. Falange", "B. Grande", "C. Trapecio", "D. Cuneiforme"],
        respuesta: 3,
    },
    {
        titulo: "PREGUNTA 8",
        pregunta: "¿Qué acción no realiza el músculo deltoides?",
        opciones: ["A. Abducción", "B. Flexión de codo", "C. Extensión de hombro", "D. Flexión de hombro"],
        respuesta: 1,
    },
    {
        titulo: "PREGUNTA 9",
        pregunta: "¿Dónde se encuentra el tendón de Aquiles?",
        opciones: ["A. En la parte interna del codo", "B. En la rodilla", "C. En el talón del pie", "D. En los isquiotibiales"],
        respuesta: 2,
    },
    {
        titulo: "PREGUNTA 10",
        pregunta: "¿Dónde se encuentra el ligamento cruzado anterior?",
        opciones: ["A. Entre el cúbito y el radio", "B. Entre el trocánter y el glúteo medio", "C. Se inserta en el epicóndilo del codo", "D. Dentro de la articulación de la rodilla"],
        respuesta: 3,
    }

];
//variable para indicar pregunta actual
let iPreguntaActual = 0;
//variable para mostrar la puntuacion
let puntuacion = 0;
// Función para mostrar la pregunta actual
function mostrarPregunta(indice) {
    const preguntaActual = preguntas[indice];
    document.getElementById("titulo").innerText = preguntaActual.titulo;
    document.getElementById("pregunta").innerText = preguntaActual.pregunta;
    document.getElementById("contador").innerText = (indice + 1) + "/" + preguntas.length; //contador va pasando a medida que vas cambiando de pregunta

    // Bucle para iterar las opciones de respuesta
    for (let i = 0; i < preguntaActual.opciones.length; i++) {
        const opcionElement = document.getElementById("opcion" + (i + 1));
        opcionElement.innerText = preguntaActual.opciones[i];
        opcionElement.classList.remove("respuesta-correcta", "respuesta-incorrecta");
        opcionElement.classList.add("hover:bg-blue-500", "cursor-pointer");
        opcionElement.setAttribute("onclick", "verificarRespuesta(id)");
    }
}
 //Funcion para verificar la respuesta
function verificarRespuesta(opcionSeleccionadaId) {
    const preguntaActual = preguntas[iPreguntaActual];
    const respuestaCorrecta = preguntaActual.respuesta;

    // Obtener el índice de la opción seleccionada
    const opcionIndex = parseInt(opcionSeleccionadaId[opcionSeleccionadaId.length - 1]) - 1;

    // Obtener el elemento HTML de la opción seleccionada
    const opcionElement = document.getElementById(opcionSeleccionadaId);

    // Verificar si la opción seleccionada es la respuesta correcta o incorrecta
    if (opcionIndex === respuestaCorrecta) {
        opcionElement.classList.add("respuesta-correcta");
        puntuacion++;
    } else {
        opcionElement.classList.add("respuesta-incorrecta");
    }
    // Actualizar la puntuación mostrada
    document.getElementById("puntuacion").innerText = "Puntuacion: " + puntuacion;

    // Deshabilitar la selección de opciones después de verificar
    const opciones = document.querySelectorAll(".bg-white");
    opciones.forEach(opcion => {
        opcion.classList.remove("hover:bg-blue-500", "cursor-pointer");
        opcion.removeAttribute("onclick");
    });
}

function siguientePregunta() {
    // Verificar si se ha seleccionado alguna opción antes de avanzar
    const opcionesSeleccionadas = document.querySelectorAll(".opcion.respuesta-correcta, .opcion.respuesta-incorrecta");
    if (opcionesSeleccionadas.length === 0) {
        alert("Por favor, selecciona una opción antes de continuar.");
        return;
    }
    //Una vez acabado el cuestionario, sale la puntuacion final
    iPreguntaActual++;
    if (iPreguntaActual < preguntas.length) {
        mostrarPregunta(iPreguntaActual);
    } else {
        alert("¡Has respondido todas las preguntas! \nPuntuacion final: " + puntuacion);
    }
}

// Mostrar la primera pregunta al cargar la página
mostrarPregunta(iPreguntaActual);